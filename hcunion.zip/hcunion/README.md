# HCUnion Client

A small client mod for **Eaglercraft 1.8** (works with the TeaVM **WASM-GC** build — no reflection, threads or file IO).

| Module | What it does |
|---|---|
| **AutoClicker** | Slider 1–25 CPS (drag, mouse-wheel or ←/→), randomize, hold-mouse-only, pause on blocks |
| **AimAssist** | Slider for range + speed. Press the lock key (default **I**) while looking at a player → only that player is aimed at, inside your range. Press again to release |
| **AutoRod** | Enable it → swaps to rod, casts once, swaps back to sword, turns itself off. Cast delay and swap-back delay are sliders |
| **Macros** | 5 key-bound macros: `slot 2; wait 50; use; wait 120; slot 1`, `say /hub`, `click`, `swing` |

Open the GUI with **Right Shift** (rebindable in the *Client* panel). Right-click a key row to clear it. Settings are saved in browser storage.

## Install

1. Get an Eaglercraft 1.8 source workspace.
2. `python3 install.py /path/to/workspace`
3. Compile the WASM-GC client with your workspace's normal build script.

The installer only touches two vanilla files: `Minecraft.java` (one call in `runTick`, plus `clickMouse`/`rightClickMouse` made `public`) and `GuiIngame.java` (one call at the start of `renderGameOverlay`).

If your workspace's `EagRuntime` has a different package or storage method names, fix them in `HCUnion.java` (only used in `save()`/`load()`).

## Macro commands
`say <text>` · `slot <1-9>` · `use` · `click` · `swing` · `wait <ms>` — separated by `;`

## Note
Delays and clicks are processed every game tick (50 ms). Cheating clients can get you banned on servers that don't allow them — use responsibly.
