package net.hcunion.client;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;

public abstract class Module {
    public final String name;
    public boolean enabled;
    public int panelWidth = 130;
    public final List<Setting> settings = new ArrayList<Setting>();
    public final Setting toggleKey = Setting.key("Toggle Key", 0);

    protected Module(String name) { this.name = name; }

    protected Setting add(Setting s) { settings.add(s); return s; }

    /** toggle key first, then the module's own settings (used by GUI + config). */
    public List<Setting> all() {
        List<Setting> l = new ArrayList<Setting>();
        l.add(toggleKey);
        l.addAll(settings);
        return l;
    }

    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
        HCUnion.dirty = true;
    }

    public void toggle() { setEnabled(!enabled); }

    protected void onEnable() { }
    protected void onDisable() { }
    public void onTick() { }
    public String hudInfo() { return ""; }
    public boolean persistEnabled() { return true; }

    protected Minecraft mc() { return Minecraft.getMinecraft(); }
}
