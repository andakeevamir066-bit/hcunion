package net.hcunion.client;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import net.hcunion.client.gui.ClickGui;
import net.hcunion.client.modules.AimAssist;
import net.hcunion.client.modules.AutoClicker;
import net.hcunion.client.modules.AutoRod;
import net.hcunion.client.modules.ClientModule;
import net.hcunion.client.modules.MacroModule;
import net.lax1dude.eaglercraft.v1_8.EagRuntime;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ChatComponentText;

/** Entry point. Only two hooks into vanilla code: onTick() and renderHud(). */
public class HCUnion {
    public static final String NAME = "HCUnion";
    public static final String VERSION = "1.0";
    private static final String STORAGE_KEY = "hcunion_cfg";

    public static final List<Module> modules = new ArrayList<Module>();
    public static AutoClicker autoClicker;
    public static AimAssist aimAssist;
    public static AutoRod autoRod;
    public static MacroModule macros;
    public static ClientModule client;

    public static boolean dirty;
    private static boolean inited;
    private static int saveTimer;

    public static void init() {
        if (inited) return;
        inited = true;
        autoClicker = new AutoClicker();
        aimAssist = new AimAssist();
        autoRod = new AutoRod();
        macros = new MacroModule();
        client = new ClientModule();
        modules.add(autoClicker);
        modules.add(aimAssist);
        modules.add(autoRod);
        modules.add(macros);
        modules.add(client);
        load();
    }

    /** Called at the start of Minecraft.runTick(). */
    public static void onTick() {
        if (!inited) init();
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null) return;

        boolean openGui = client.guiKey.consumePress();
        if (openGui && mc.currentScreen == null) mc.displayGuiScreen(new ClickGui());

        for (Module m : modules) {
            if (m.toggleKey.consumePress() && mc.currentScreen == null) m.toggle();
        }
        for (Module m : modules) {
            if (m.enabled) m.onTick();
        }
        if (dirty && ++saveTimer > 100) { save(); }
    }

    /** Called every frame at the start of GuiIngame.renderGameOverlay(). */
    public static void renderHud(float partialTicks) {
        if (!inited) return;
        Minecraft mc = Minecraft.getMinecraft();
        aimAssist.onFrame();
        if (!client.enabled || mc.gameSettings.showDebugInfo) return;

        FontRenderer fr = mc.fontRendererObj;
        ScaledResolution sr = new ScaledResolution(mc);
        fr.drawStringWithShadow(NAME + " " + VERSION, 4, 4, 0xFF55FF55);
        int y = 4;
        for (Module m : modules) {
            if (!m.enabled || m == client) continue;
            String s = m.name + m.hudInfo();
            fr.drawStringWithShadow(s, sr.getScaledWidth() - fr.getStringWidth(s) - 4, y, 0xFFFFFFFF);
            y += 10;
        }
    }

    public static void msg(String text) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null)
            mc.thePlayer.addChatMessage(new ChatComponentText("\u00a7a[HCUnion] \u00a7f" + text));
    }

    // ---------- config (stored in Eaglercraft's browser storage) ----------
    public static void save() {
        dirty = false;
        saveTimer = 0;
        try {
            StringBuilder sb = new StringBuilder();
            for (Module m : modules) {
                if (m.persistEnabled()) sb.append(m.name).append(".#enabled=").append(m.enabled ? "1" : "0").append('\n');
                for (Setting s : m.all()) sb.append(m.name).append('.').append(s.name).append('=').append(s.serialize()).append('\n');
            }
            EagRuntime.setStorage(STORAGE_KEY, sb.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Throwable ignored) { }
    }

    private static void load() {
        try {
            byte[] data = EagRuntime.getStorage(STORAGE_KEY);
            if (data == null) return;
            String[] lines = new String(data, StandardCharsets.UTF_8).split("\n");
            for (String line : lines) {
                int eq = line.indexOf('=');
                if (eq < 0) continue;
                String left = line.substring(0, eq), val = line.substring(eq + 1);
                int dot = left.indexOf('.');
                if (dot < 0) continue;
                String mod = left.substring(0, dot), rest = left.substring(dot + 1);
                for (Module m : modules) {
                    if (!m.name.equals(mod)) continue;
                    if (rest.equals("#enabled")) { if (m.persistEnabled()) m.enabled = val.equals("1"); continue; }
                    for (Setting s : m.all()) if (s.name.equals(rest)) s.deserialize(val);
                }
            }
        } catch (Throwable ignored) { }
    }
}
