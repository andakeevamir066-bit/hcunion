package net.hcunion.client;

import org.lwjgl.input.Keyboard;

/** One configurable value (toggle, slider, keybind or text). No reflection -> TeaVM / WASM-GC safe. */
public class Setting {
    public enum Type { BOOL, SLIDER, KEY, TEXT }

    public final String name;
    public final Type type;
    public boolean b;
    public double v, min, max, step = 1;
    public String unit = "";
    public int key;
    public String text = "";
    private boolean wasDown;

    private Setting(String name, Type type) { this.name = name; this.type = type; }

    public static Setting bool(String name, boolean def) {
        Setting s = new Setting(name, Type.BOOL); s.b = def; return s;
    }
    public static Setting slider(String name, double def, double min, double max, double step, String unit) {
        Setting s = new Setting(name, Type.SLIDER);
        s.v = def; s.min = min; s.max = max; s.step = step; s.unit = unit; return s;
    }
    public static Setting key(String name, int def) {
        Setting s = new Setting(name, Type.KEY); s.key = def; return s;
    }
    public static Setting text(String name, String def) {
        Setting s = new Setting(name, Type.TEXT); s.text = def; return s;
    }

    public int asInt() { return (int) Math.round(v); }

    public void setSlider(double nv) {
        if (step > 0) nv = min + Math.round((nv - min) / step) * step;
        if (nv < min) nv = min;
        if (nv > max) nv = max;
        v = nv;
    }

    public String keyName() { return key <= 0 ? "NONE" : Keyboard.getKeyName(key); }

    public String valueString() {
        if (step >= 1) return Integer.toString(asInt());
        return Double.toString(Math.round(v * 10.0) / 10.0);
    }

    /** True once per physical key press (rising edge). Call every tick. */
    public boolean consumePress() {
        if (key <= 0) return false;
        boolean down = Keyboard.isKeyDown(key);
        boolean edge = down && !wasDown;
        wasDown = down;
        return edge;
    }

    public String serialize() {
        switch (type) {
            case BOOL: return b ? "1" : "0";
            case SLIDER: return Double.toString(v);
            case KEY: return Integer.toString(key);
            default: return text;
        }
    }

    public void deserialize(String s) {
        try {
            switch (type) {
                case BOOL: b = s.equals("1"); break;
                case SLIDER: setSlider(Double.parseDouble(s)); break;
                case KEY: key = Integer.parseInt(s); break;
                default: text = s; break;
            }
        } catch (Exception ignored) { }
    }
}
