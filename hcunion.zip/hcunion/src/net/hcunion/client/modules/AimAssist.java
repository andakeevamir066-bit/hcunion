package net.hcunion.client.modules;

import net.hcunion.client.HCUnion;
import net.hcunion.client.Module;
import net.hcunion.client.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.input.Keyboard;

/** Press the lock key while looking at a player -> only that player is aimed at, inside Range. */
public class AimAssist extends Module {
    public final Setting range = add(Setting.slider("Range", 4.5, 1, 10, 0.5, " blocks"));
    public final Setting speed = add(Setting.slider("Speed", 35, 1, 100, 1, "%"));
    public final Setting pickAngle = add(Setting.slider("Pick Angle", 25, 5, 90, 5, "\u00b0"));
    public final Setting lockKey = add(Setting.key("Lock Key", Keyboard.KEY_I));
    public final Setting holdAttack = add(Setting.bool("Hold Attack Only", false));

    private EntityPlayer target;
    private long lastFrame;

    public AimAssist() { super("AimAssist"); }

    @Override protected void onDisable() { target = null; }

    @Override public String hudInfo() { return target != null ? " [" + target.getName() + "]" : ""; }

    @Override
    public void onTick() {
        Minecraft mc = mc();
        EntityPlayerSP p = mc.thePlayer;
        boolean pressed = lockKey.consumePress();
        if (p == null || mc.currentScreen != null) return;

        if (pressed) {
            if (target != null) {
                target = null;
                HCUnion.msg("Aim lock released");
            } else {
                EntityPlayer t = pick(mc, p);
                if (t != null) { target = t; HCUnion.msg("Aim locked on " + t.getName()); }
                else HCUnion.msg("No player in view / range");
            }
        }
        if (target != null && (target.isDead || target.getHealth() <= 0 || !mc.theWorld.playerEntities.contains(target))) {
            target = null;
            HCUnion.msg("Aim lock lost target");
        }
    }

    /** Runs every frame for smooth aiming (called from HCUnion.renderHud). */
    public void onFrame() {
        long now = System.currentTimeMillis();
        double dt = lastFrame == 0 ? 0.016 : Math.min(0.1, (now - lastFrame) / 1000.0);
        lastFrame = now;

        Minecraft mc = mc();
        EntityPlayerSP p = mc.thePlayer;
        if (!enabled || target == null || p == null || mc.currentScreen != null) return;
        if (holdAttack.b && !mc.gameSettings.keyBindAttack.isKeyDown()) return;
        if (p.getDistanceToEntity(target) > range.v) return;

        float[] r = rotationsTo(p, target);
        float dyaw = MathHelper.wrapAngleTo180_float(r[0] - p.rotationYaw);
        float dpitch = r[1] - p.rotationPitch;
        if (Math.abs(dyaw) < 0.05f && Math.abs(dpitch) < 0.05f) return;

        double f = 1.0 - Math.pow(1.0 - speed.v / 100.0, dt * 20.0);
        float sy = (float) (dyaw * f);
        float sp = (float) (dpitch * f);
        float newPitch = MathHelper.clamp_float(p.rotationPitch + sp, -90.0f, 90.0f);
        float appliedPitch = newPitch - p.rotationPitch;

        p.rotationYaw += sy;
        p.prevRotationYaw += sy;
        p.rotationPitch = newPitch;
        p.prevRotationPitch += appliedPitch;
    }

    private EntityPlayer pick(Minecraft mc, EntityPlayerSP p) {
        MovingObjectPosition mop = mc.objectMouseOver;
        if (mop != null && mop.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY
                && mop.entityHit instanceof EntityPlayer && mop.entityHit != p
                && p.getDistanceToEntity(mop.entityHit) <= range.v) {
            return (EntityPlayer) mop.entityHit;
        }
        EntityPlayer best = null;
        double bestAng = pickAngle.v;
        for (EntityPlayer e : mc.theWorld.playerEntities) {
            if (e == p || e.isDead || e.getHealth() <= 0) continue;
            if (p.getDistanceToEntity(e) > range.v) continue;
            float[] r = rotationsTo(p, e);
            double a = MathHelper.wrapAngleTo180_float(r[0] - p.rotationYaw);
            double b = r[1] - p.rotationPitch;
            double ang = Math.sqrt(a * a + b * b);
            if (ang < bestAng) { bestAng = ang; best = e; }
        }
        return best;
    }

    private static float[] rotationsTo(EntityPlayerSP p, EntityPlayer e) {
        double dx = e.posX - p.posX;
        double dz = e.posZ - p.posZ;
        double dy = (e.posY + e.height * 0.8) - (p.posY + p.getEyeHeight());
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(Math.atan2(dy, h) * 180.0 / Math.PI);
        return new float[] { yaw, pitch };
    }
}
