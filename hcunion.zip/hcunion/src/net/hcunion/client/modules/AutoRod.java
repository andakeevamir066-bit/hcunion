package net.hcunion.client.modules;

import net.hcunion.client.HCUnion;
import net.hcunion.client.Module;
import net.hcunion.client.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

/**
 * Enable it -> swaps to the rod, casts once, swaps back to the sword, then (optionally) turns itself off.
 * Delays are checked every game tick (50 ms steps).
 */
public class AutoRod extends Module {
    public final Setting switchDelay = add(Setting.slider("Cast Delay", 80, 0, 500, 10, " ms"));
    public final Setting backDelay = add(Setting.slider("Swap Back Delay", 120, 0, 500, 10, " ms"));
    public final Setting autoDisable = add(Setting.bool("Auto Disable", true));
    public final Setting castKey = add(Setting.key("Re-cast Key", 0));

    private static final int IDLE = 0, START = 1, WAIT_CAST = 2, WAIT_BACK = 3;
    private int state = IDLE;
    private long t;
    private int returnSlot;

    public AutoRod() { super("AutoRod"); }

    @Override public boolean persistEnabled() { return false; }

    @Override protected void onEnable() { state = START; }
    @Override protected void onDisable() { state = IDLE; }

    @Override
    public void onTick() {
        Minecraft mc = mc();
        EntityPlayerSP p = mc.thePlayer;
        if (p == null) return;
        boolean recast = castKey.consumePress();
        if (state == IDLE && recast && mc.currentScreen == null) state = START;

        int guard = 0;
        boolean progress = true;
        while (progress && guard++ < 4) {
            progress = false;
            long now = System.currentTimeMillis();
            switch (state) {
                case START:
                    if (!begin(p)) return;
                    state = WAIT_CAST; t = now; progress = true;
                    break;
                case WAIT_CAST:
                    if (now - t >= switchDelay.asInt()) {
                        mc.playerController.sendUseItem(p, mc.theWorld, p.inventory.getCurrentItem());
                        p.swingItem();
                        state = WAIT_BACK; t = now; progress = true;
                    }
                    break;
                case WAIT_BACK:
                    if (now - t >= backDelay.asInt()) {
                        p.inventory.currentItem = returnSlot;
                        state = IDLE;
                        if (autoDisable.b) setEnabled(false);
                    }
                    break;
                default: break;
            }
        }
    }

    private boolean begin(EntityPlayerSP p) {
        int prev = p.inventory.currentItem;
        int rod = -1, sword = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.inventory.mainInventory[i];
            if (s == null) continue;
            Item it = s.getItem();
            if (rod == -1 && it instanceof ItemFishingRod) rod = i;
            if (it instanceof ItemSword && (sword == -1 || i == prev)) sword = i;
        }
        if (rod == -1) {
            HCUnion.msg("AutoRod: no fishing rod in your hotbar");
            setEnabled(false);
            return false;
        }
        returnSlot = sword != -1 ? sword : prev;
        p.inventory.currentItem = rod;
        return true;
    }
}
