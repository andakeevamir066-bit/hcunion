package net.hcunion.client.modules;

import java.util.ArrayList;
import java.util.List;

import net.hcunion.client.Module;
import net.hcunion.client.Setting;
import net.minecraft.client.Minecraft;

/**
 * 5 key-bound macros. Script = steps separated by ';'
 *   say <text>   chat message or /command
 *   slot <1-9>   select hotbar slot
 *   use          right click
 *   click        left click
 *   swing        swing arm
 *   wait <ms>    pause
 * Example:  slot 2; wait 50; use; wait 120; slot 1
 */
public class MacroModule extends Module {
    private static final int COUNT = 5;
    private final Setting[] keys = new Setting[COUNT];
    private final Setting[] scripts = new Setting[COUNT];

    private final List<String> steps = new ArrayList<String>();
    private boolean running;
    private int idx;
    private long waitUntil;

    public MacroModule() {
        super("Macros");
        panelWidth = 280;
        for (int i = 0; i < COUNT; i++) {
            keys[i] = add(Setting.key("Macro " + (i + 1) + " Key", 0));
            scripts[i] = add(Setting.text("Macro " + (i + 1), i == 0 ? "slot 2; wait 50; use; wait 120; slot 1" : ""));
        }
    }

    @Override protected void onDisable() { running = false; }

    @Override
    public void onTick() {
        Minecraft mc = mc();
        if (mc.thePlayer == null) return;
        for (int i = 0; i < COUNT; i++) {
            if (keys[i].consumePress() && mc.currentScreen == null && !running) start(scripts[i].text);
        }
        run(mc);
    }

    private void start(String script) {
        steps.clear();
        for (String s : script.split(";")) {
            s = s.trim();
            if (s.length() > 0 && steps.size() < 64) steps.add(s);
        }
        if (steps.isEmpty()) return;
        idx = 0; waitUntil = 0; running = true;
    }

    private void run(Minecraft mc) {
        long now = System.currentTimeMillis();
        while (running) {
            if (now < waitUntil) return;
            if (idx >= steps.size()) { running = false; return; }
            exec(mc, steps.get(idx++));
            now = System.currentTimeMillis();
        }
    }

    private void exec(Minecraft mc, String step) {
        int sp = step.indexOf(' ');
        String cmd = (sp < 0 ? step : step.substring(0, sp)).toLowerCase();
        String arg = sp < 0 ? "" : step.substring(sp + 1).trim();
        if (cmd.equals("say") || cmd.equals("chat")) {
            if (arg.length() > 0) mc.thePlayer.sendChatMessage(arg);
        } else if (cmd.equals("slot")) {
            int n = num(arg, 1);
            if (n >= 1 && n <= 9) mc.thePlayer.inventory.currentItem = n - 1;
        } else if (cmd.equals("use")) {
            mc.rightClickMouse();          // made public by install.py
        } else if (cmd.equals("click")) {
            mc.clickMouse();               // made public by install.py
        } else if (cmd.equals("swing")) {
            mc.thePlayer.swingItem();
        } else if (cmd.equals("wait")) {
            waitUntil = System.currentTimeMillis() + Math.max(0, Math.min(10000, num(arg, 0)));
        }
    }

    private static int num(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return def; }
    }
}
