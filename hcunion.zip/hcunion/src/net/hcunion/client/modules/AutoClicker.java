package net.hcunion.client.modules;

import java.util.Random;

import net.hcunion.client.Module;
import net.hcunion.client.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.MovingObjectPosition;

public class AutoClicker extends Module {
    public final Setting cps = add(Setting.slider("CPS", 12, 1, 25, 1, " cps"));
    public final Setting randomize = add(Setting.bool("Randomize", true));
    public final Setting holdOnly = add(Setting.bool("Hold Mouse Only", true));
    public final Setting pauseOnBlocks = add(Setting.bool("Pause On Blocks", true));

    private long nextClick;
    private final Random rnd = new Random();

    public AutoClicker() { super("AutoClicker"); }

    @Override protected void onDisable() { nextClick = 0; }

    @Override public String hudInfo() { return " [" + cps.asInt() + "]"; }

    private long interval() {
        double base = 1000.0 / cps.v;
        if (randomize.b) base *= 0.8 + rnd.nextDouble() * 0.4;
        return Math.max(20L, (long) base);
    }

    @Override
    public void onTick() {
        Minecraft mc = mc();
        if (mc.thePlayer == null || mc.currentScreen != null) { nextClick = 0; return; }
        if (holdOnly.b && !mc.gameSettings.keyBindAttack.isKeyDown()) { nextClick = 0; return; }
        if (pauseOnBlocks.b && mc.objectMouseOver != null
                && mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) { nextClick = 0; return; }

        long now = System.currentTimeMillis();
        if (nextClick == 0) nextClick = now + interval();
        int guard = 0;
        while (now >= nextClick && guard++ < 3) {
            mc.clickMouse();               // made public by install.py
            nextClick += interval();
        }
        if (now - nextClick > 250) nextClick = now;
    }
}
