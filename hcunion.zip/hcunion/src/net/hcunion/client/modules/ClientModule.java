package net.hcunion.client.modules;

import net.hcunion.client.Module;
import net.hcunion.client.Setting;
import org.lwjgl.input.Keyboard;

/** HUD on/off + the key that opens the GUI. */
public class ClientModule extends Module {
    public final Setting guiKey = add(Setting.key("GUI Key", Keyboard.KEY_RSHIFT));

    public ClientModule() {
        super("Client");
        enabled = true;
    }
}
