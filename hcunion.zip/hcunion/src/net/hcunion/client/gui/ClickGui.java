package net.hcunion.client.gui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.hcunion.client.HCUnion;
import net.hcunion.client.Module;
import net.hcunion.client.Setting;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ChatAllowedCharacters;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class ClickGui extends GuiScreen {
    private static final int ROW = 16, HEAD = 18;

    private static class Hit { int x1, y1, x2, y2; Module m; Setting s; }

    private final List<Hit> hits = new ArrayList<Hit>();
    private Hit dragging;
    private Setting binding, editing;
    private int mx, my;

    @Override public boolean doesGuiPauseGame() { return false; }
    @Override public void onGuiClosed() { HCUnion.save(); }

    @Override
    public void drawScreen(int mouseX, int mouseY, float pt) {
        mx = mouseX; my = mouseY;
        hits.clear();
        drawRect(0, 0, width, height, 0x99000000);
        FontRenderer fr = fontRendererObj;
        fr.drawStringWithShadow(HCUnion.NAME + " Client  |  click header = on/off  |  drag / scroll / left-right arrows = adjust sliders", 8, 6, 0xFFFFFFFF);

        int x = 8, y = 20, rowH = 0;
        for (Module m : HCUnion.modules) {
            int w = m.panelWidth;
            int h = HEAD + m.all().size() * ROW;
            if (x > 8 && x + w > width - 8) { x = 8; y += rowH + 8; rowH = 0; }
            drawPanel(m, x, y, w, fr);
            if (h > rowH) rowH = h;
            x += w + 8;
        }
        super.drawScreen(mouseX, mouseY, pt);
    }

    private void drawPanel(Module m, int x, int y, int w, FontRenderer fr) {
        Hit hh = hit(x, y, x + w, y + HEAD, m, null);
        drawRect(x, y, x + w, y + HEAD, m.enabled ? 0xFF2E7D32 : 0xFF4A4A4A);
        drawCenteredString(fr, m.name + (m.enabled ? "  [ON]" : "  [OFF]"), x + w / 2, y + 5, 0xFFFFFFFF);

        int ry = y + HEAD;
        for (Setting s : m.all()) {
            Hit h = hit(x, ry, x + w, ry + ROW, m, s);
            drawRect(x, ry, x + w, ry + ROW, inside(h) ? 0xE0343434 : 0xE0202020);
            switch (s.type) {
                case BOOL:
                    drawString(fr, s.name, x + 4, ry + 4, 0xFFFFFFFF);
                    String on = s.b ? "ON" : "OFF";
                    drawString(fr, on, x + w - 4 - fr.getStringWidth(on), ry + 4, s.b ? 0xFF55FF55 : 0xFFFF5555);
                    break;
                case SLIDER:
                    int fill = (int) (w * (s.v - s.min) / (s.max - s.min));
                    drawRect(x, ry, x + fill, ry + ROW, 0xFF2F6DB5);
                    drawString(fr, s.name + ": " + s.valueString() + s.unit, x + 4, ry + 4, 0xFFFFFFFF);
                    break;
                case KEY:
                    drawString(fr, s.name + ": " + (binding == s ? "press a key..." : s.keyName()), x + 4, ry + 4, 0xFFFFFFFF);
                    break;
                default:
                    String prefix = s.name + ": ";
                    int avail = w - 8 - fr.getStringWidth(prefix);
                    String shown = editing == s ? fr.trimStringToWidth(s.text + "_", avail, true) : fr.trimStringToWidth(s.text, avail);
                    drawString(fr, prefix, x + 4, ry + 4, 0xFFAAAAAA);
                    drawString(fr, shown, x + 4 + fr.getStringWidth(prefix), ry + 4, 0xFFFFFFFF);
                    break;
            }
            ry += ROW;
        }
    }

    private Hit hit(int x1, int y1, int x2, int y2, Module m, Setting s) {
        Hit h = new Hit();
        h.x1 = x1; h.y1 = y1; h.x2 = x2; h.y2 = y2; h.m = m; h.s = s;
        hits.add(h);
        return h;
    }

    private boolean inside(Hit h) { return mx >= h.x1 && mx < h.x2 && my >= h.y1 && my < h.y2; }

    private void updateSlider(Hit h, int mouseX) {
        double f = (mouseX - h.x1) / (double) (h.x2 - h.x1);
        if (f < 0) f = 0; if (f > 1) f = 1;
        h.s.setSlider(h.s.min + f * (h.s.max - h.s.min));
        HCUnion.dirty = true;
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        binding = null; editing = null;
        mx = mouseX; my = mouseY;
        for (Hit h : hits) {
            if (!inside(h)) continue;
            if (h.s == null) { if (button == 0) h.m.toggle(); return; }
            switch (h.s.type) {
                case BOOL: if (button == 0) h.s.b = !h.s.b; break;
                case SLIDER: if (button == 0) { dragging = h; updateSlider(h, mouseX); } break;
                case KEY: if (button == 0) binding = h.s; else if (button == 1) h.s.key = 0; break;
                default: editing = h.s; break;
            }
            HCUnion.dirty = true;
            return;
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int button, long time) {
        mx = mouseX; my = mouseY;
        if (dragging != null) updateSlider(dragging, mouseX);
    }

    @Override protected void mouseReleased(int mouseX, int mouseY, int state) { dragging = null; }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int wheel = Mouse.getEventDWheel();
        if (wheel != 0) nudgeHovered(wheel > 0 ? 1 : -1);
    }

    private void nudgeHovered(int dir) {
        for (Hit h : hits) {
            if (h.s != null && h.s.type == Setting.Type.SLIDER && inside(h)) {
                h.s.setSlider(h.s.v + dir * h.s.step);
                HCUnion.dirty = true;
                return;
            }
        }
    }

    @Override
    protected void keyTyped(char c, int keyCode) throws IOException {
        if (binding != null) {
            binding.key = keyCode == Keyboard.KEY_ESCAPE ? 0 : keyCode;
            binding = null; HCUnion.dirty = true;
            return;
        }
        if (editing != null) {
            if (keyCode == Keyboard.KEY_ESCAPE || keyCode == Keyboard.KEY_RETURN || keyCode == Keyboard.KEY_NUMPADENTER) {
                editing = null;
            } else if (keyCode == Keyboard.KEY_BACK) {
                if (editing.text.length() > 0) editing.text = editing.text.substring(0, editing.text.length() - 1);
            } else if (ChatAllowedCharacters.isAllowedCharacter(c) && editing.text.length() < 200) {
                editing.text += c;
            }
            HCUnion.dirty = true;
            return;
        }
        if (keyCode == Keyboard.KEY_LEFT) { nudgeHovered(-1); return; }
        if (keyCode == Keyboard.KEY_RIGHT) { nudgeHovered(1); return; }
        if (keyCode == Keyboard.KEY_ESCAPE || keyCode == HCUnion.client.guiKey.key) {
            mc.displayGuiScreen(null);
        }
    }
}
