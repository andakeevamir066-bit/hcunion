#!/usr/bin/env python3
"""
HCUnion installer for an Eaglercraft 1.8 source workspace.

    python3 install.py /path/to/your/eaglercraft-workspace

 - copies src/net/hcunion into the workspace's game source folder
 - patches Minecraft.java   (hook in runTick, makes clickMouse/rightClickMouse public)
 - patches GuiIngame.java   (HUD / per-frame hook)
Backups are written next to each patched file as *.hcbak. Safe to run twice.
"""
import os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))

def find(root, name, must):
    for d, _, files in os.walk(root):
        if name in files and must in os.path.join(d, name).replace("\\", "/"):
            return os.path.join(d, name)
    return None

def patch(path, fn):
    with open(path, encoding="utf-8") as f: old = f.read()
    new = fn(old)
    if new != old:
        shutil.copy(path, path + ".hcbak")
        with open(path, "w", encoding="utf-8", newline="") as f: f.write(new)
        print("patched", path)
    else:
        print("no change (already patched?)", path)

def patch_mc(t):
    t = re.sub(r"private void (clickMouse|rightClickMouse)\(\)", r"public void \1()", t)
    if "HCUnion.onTick" not in t:
        t, n = re.subn(r"(public void runTick\(\)[^{]*\{)", r"\1\n\t\tnet.hcunion.client.HCUnion.onTick();", t, count=1)
        if n == 0: print("!! could not find runTick() - add HCUnion.onTick() by hand")
    return t

def patch_gui(t):
    if "HCUnion.renderHud" in t: return t
    t, n = re.subn(r"(public void renderGameOverlay\(float\s+(\w+)\)[^{]*\{)",
                   r"\1\n\t\tnet.hcunion.client.HCUnion.renderHud(\2);", t, count=1)
    if n == 0: print("!! could not find renderGameOverlay() - add HCUnion.renderHud(partialTicks) by hand")
    return t

def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    ws = sys.argv[1]
    mc = find(ws, "Minecraft.java", "net/minecraft/client/")
    gi = find(ws, "GuiIngame.java", "net/minecraft/client/gui/")
    if not mc or not gi: sys.exit("Could not find Minecraft.java / GuiIngame.java under " + ws)
    src_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(mc))))
    dest = os.path.join(src_root, "net", "hcunion")
    shutil.copytree(os.path.join(HERE, "src", "net", "hcunion"), dest, dirs_exist_ok=True)
    print("copied client to", dest)
    patch(mc, patch_mc)
    patch(gi, patch_gui)
    print("done. Now compile your WASM-GC client as usual.")

main()
